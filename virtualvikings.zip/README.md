### Virtual Vikings

#### Training
- The new knowledge base files should be added to the `knowledge` folder.

### Chatbot
- Install all the requirements by running `pip install -r requirements.txt`
- The chatbot can be run using `python chatbot.py`
